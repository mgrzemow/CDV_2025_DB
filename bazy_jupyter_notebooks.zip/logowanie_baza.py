# Sluchacz1 .. Sluchacz12
# Sluchacz1_passwd .. Sluchacz12_passwd
# Postaram sie do końca tygodnia szkolenia utrzymać bazę na chodzie.
user = 'Sluchacz12'
password = 'Sluchacz12_passwd'
dsn = '6.tcp.eu.ngrok.io:17482/xe'
